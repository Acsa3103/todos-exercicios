const listaCPFs = [1111111, 22222, 3333];
const informacoesPessoa = ["nome", "Jose", "idade", 32, "CPF", "1111222333"];
console.log(informacoesPessoa[1]);
console.log(listaCPFs[0]) 