const cliente = {
    nome: "Robson",
    idade: 29,
    cpf: "05085045578",
    email: "robinho@polo.com.br",
};
  console.log(cliente)