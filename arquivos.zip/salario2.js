let salario = 3000;
let result = 0;

if (salario >= 3500) {
    (result=salario-300) }
else
if (salario >= 3100) {
    result = salario-200}
else
result=salario-100;

console.log("O valor final do salario com descontos é de:" + result)
