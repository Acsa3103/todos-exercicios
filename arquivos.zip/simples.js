var pais="Austrália"

console.log(`Você esta morando no(a) ${pais}`)

if (pais=="Brasil"){
    console.log("Você é brasileiro!!")
} else {
    console.log("Você é estrangeiro.")
}