n=70
if (n>=200) {// true
        console.log("O valor de N é MAIOR que 200!")
}else{
  if (n>=100) {//true
        console.log("O valor de N é MAIOR que 100!")
        } else {//false
        console.log("O valor de N é MENOR que 100!")
}
}