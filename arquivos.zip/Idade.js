let idade = 28
let result = "";

if(idade >= 60){result="Pode aposentar"}
else
if(idade >=55){result="Já pode pedir aposentadoria"}
else
{result="Ainda não tem idade para aposentar"}

console.log("O seu cliente: "+ result)