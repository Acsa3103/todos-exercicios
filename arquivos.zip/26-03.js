var n = 200 
var t = 'Oi Brasil, cheguei, cheguei Brasil'
x=n*t
console.log(x)